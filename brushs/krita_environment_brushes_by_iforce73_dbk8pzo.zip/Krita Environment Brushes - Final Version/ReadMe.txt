Environment Brushes for Krita is licensed under a creative commons Attribution 3.0 Unported License.All Brushes are created by IForce73 (except LJF Water Brush and Dotted Flat Brush from Krita's internal Brushset).Brush icons are modified by me.Original Versions are taken from kdr.org and openclipart.org






